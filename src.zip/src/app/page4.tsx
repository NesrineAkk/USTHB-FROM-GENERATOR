import React from 'react';
import HomePageHeader from "@/components/HomePageHeader"

export default function Page4() {
  return (
    <main className="container mx-auto px-2 sm:px-4">
      {/* En-tête ultra-compact */}
      <HomePageHeader title='Drafts' description='Retrouvez tous vos drafts enregistrés et modifiez-les facilement.'></HomePageHeader>

      <hr className="mb-6 border-t border-muted" />

      <div>
        {/* Grille de drafts */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Ajoutez ici les cartes de drafts si nécessaire */}
        </div>
      </div>
    </main>
  );
}