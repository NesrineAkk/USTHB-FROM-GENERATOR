import React from 'react';
import HomePageHeader from "@/components/HomePageHeader"

export default function Page3() {
  return (
    <main className="container mx-auto px-2 sm:px-4">
      {/* En-tête ultra-compact */}
      <HomePageHeader title='Mes formulaires' description=' Retrouvez tous vos formulaires enregistrés et modifiez-les facilement.'></HomePageHeader>

      <hr className="mb-6 border-t border-muted" />

      {/* Grille de formulaires */}
      <div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Ajoutez ici les cartes de formulaire si nécessaire */}
        </div>
      </div>
    </main>
  );
}