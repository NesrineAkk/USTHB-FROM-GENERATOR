'use client';

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { PlusCircle } from "lucide-react"
import HomePageHeader from "@/components/HomePageHeader"
import { useRouter } from "next/navigation";

export default function Page1() {
  const router = useRouter();
  const goToCreateForm = ()=>{
    router.push('/create-form');
  }
  return (
    <main className="container mx-auto px-2 sm:px-4"> {/* Padding vertical réduit */}
      {/* En-tête ultra-compact */}
      <HomePageHeader title="Formulaire" description="Générez des formulaires officiels rapidement et efficacement avec l'IA."></HomePageHeader>

      <hr className="mb-6 border-t border-muted" /> {/* Trait plus fin */}

      {/* Section création */}
      <Card className="mb-8 p-6">
        <CardContent className="px-0 flex justify-between items-center"> {/* Padding réduit */}
          <div>
            <h2 className="font-semibold text-base"> {/* Taille ajustée */}
              Créer un formulaire à partir de zéro
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5"> {/* Texte plus petit */}
              Utilisez l'IA pour générer un formulaire personnalisé adapté à vos besoins.
            </p>
          </div>
          <Button className="bg-blue-600 hover:bg-blue-700 ml-2" onClick={goToCreateForm}>
            <PlusCircle className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Créer</span>
          </Button> {/* Bleu forcé */}
        </CardContent>
      </Card>


      {/* Dernière carte */}
      <div>
        <h2 className="text-2xl mb-6 font-extrabold">Suggested Forms</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6"> {/* Espacement réduit */}
          <Card className="p-6 border-1 border-dashed border-blue-700">
            <CardContent className="px-0"> {/* Padding réduit */}
              <h3 className="font-semibold text-sm"> {/* Taille réduite */}
                Créer un modèle de formulaire
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5"> {/* Texte plus petit */}
                Ce modèle sera ajouté aux formulaires suggérés pour une utilisation rapide.
              </p>
            </CardContent>
            <CardFooter className="px-0"> {/* Padding ajusté */}
              <Button className="w-fit bg-blue-600 hover:bg-blue-700 text-sm">
                <PlusCircle className="mr-1.5 h-3.5 w-3.5" /> {/* Styles forcés */}
                Créer un formulaire
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>

    </main>
  )
}